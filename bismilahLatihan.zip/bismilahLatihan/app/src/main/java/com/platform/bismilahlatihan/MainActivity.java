package com.platform.bismilahlatihan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.net.Uri;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnIg = findViewById(R.id.btnIg);
        btnIg.setOnClickListener(this);

        Button btnFb = findViewById(R.id.btnFb);
        btnFb.setOnClickListener(this);

        Button Profile = findViewById(R.id.Profile);
        Profile.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){
        switch(v.getId()){
            case R.id.btnIg:
                Uri Ig =Uri.parse("http://www.instagram.com/");
                Intent instagram = new Intent(Intent.ACTION_VIEW, Ig);
                startActivity(instagram);
                break;
            case R.id.btnFb:
                Uri Fb = Uri.parse("http://www.facebook.com/");
                Intent facebook = new Intent(Intent.ACTION_VIEW, Fb);
                startActivity(facebook);
                break;
            case R.id.Profile:
                startActivity(new Intent(MainActivity.this, profil.class));
                break;
        }
    }
}